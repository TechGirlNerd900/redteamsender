// main.js - Using CommonJS modules
const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');
const { Buffer } = require('buffer');
const nodemailer = require('nodemailer');
const fs = require('fs/promises');
const winston = require('winston');
const randomstring = require('randomstring');
const { validateSmtpConfig } = require('./server/utils/validationUtils');
const { getCurrentSmtpConfig, getCurrentTemplate } = require('./server/utils/rotationUtils');
const { sendEmail } = require('./server/services/emailService');
const Store = require('electron-store');
const { contextBridge, ipcRenderer } = require('electron');

// Initialize stores
const store = new Store({
  name: 'smtp-configs',
  encryptionKey: 'your-secure-key',
  clearInvalidConfig: true
});

const templateStore = new Store({
  name: 'email-templates',
  encryptionKey: 'your-secure-key',
  clearInvalidConfig: true,
  defaults: {
    templates: []
  }
});

console.log('Stores initialized');

// Initialize logger
const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
  ),
  transports: [
    new winston.transports.File({
      filename: path.join(app.getPath('userData'), 'logs', 'error.log'),
      level: 'error'
    }),
    new winston.transports.File({
      filename: path.join(app.getPath('userData'), 'logs', 'combined.log')
    })
  ]
});

let mainWindow;
let isSendingEmails = false;
let cancelSendingRequested = false;

// Set development mode based on environment variable or default to production
const isDev = process.env.NODE_ENV === 'development';

// DevTools completely disabled in this application

// In a standalone EXE, we don't need a separate server
// All functionality is handled through IPC

// Create main window function
const createWindow = () => {
  console.log('Creating main window');

  // Log the preload script path
  const preloadPath = path.join(__dirname, 'preload.js');
  console.log('Preload script path:', preloadPath);

  mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: preloadPath,
      webSecurity: true, // Enable web security
      allowRunningInsecureContent: false, // Don't allow insecure content
      enableRemoteModule: false,
      sandbox: false, // Disable sandbox to ensure proper event handling
      devTools: false // Completely disable DevTools
    },
    backgroundColor: '#121212', // Dark background color
    icon: path.join(__dirname, 'assets', 'app.ico'), // Windows icon
    // Ensure proper focus handling
    focusable: true,
    show: false // Don't show until ready-to-show
  });

  // Show window when ready to avoid blank screen issues
  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
    mainWindow.focus();
  });

  // Register window event handlers
  mainWindow.webContents.on('did-fail-load', (event, errorCode, errorDescription) => {
    console.error('Failed to load:', errorCode, errorDescription);
  });

  mainWindow.webContents.on('did-finish-load', () => {
    console.log('Window finished loading');
  });

  mainWindow.webContents.on('dom-ready', () => {
    console.log('DOM is ready');
  });

  if (isDev) {
    mainWindow.loadURL('http://localhost:3000');
    // DevTools disabled in all environments
  } else {
    // Use file protocol with correct path
    const indexPath = path.join(__dirname, 'client', 'build', 'index.html');
    console.log('Loading index.html from:', indexPath);

    // Set the base directory for relative paths
    mainWindow.loadFile(indexPath, {
      baseURLForDataURL: `file://${path.join(__dirname, 'client', 'build')}/`
    });
    // DevTools completely disabled
  }

  return mainWindow;
};

// Ensure logs directory exists before app is ready
(async () => {
  try {
    await fs.mkdir(path.join(app.getPath('userData'), 'logs'), { recursive: true });
  } catch (error) {
    logger.warn('Logs directory may already exist');
  }
})();

// App lifecycle events
app.whenReady().then(() => {
  console.log('App is ready');

  // Initialize template store if needed
  if (!templateStore.has('templates')) {
    console.log('Initializing template store with empty array');
    templateStore.set('templates', []);
  } else {
    console.log('Template store already initialized with:', templateStore.get('templates'));
  }

  // Disable keyboard shortcuts for DevTools and context menu
  app.on('web-contents-created', (event, contents) => {
    // Disable keyboard shortcuts
    contents.on('before-input-event', (event, input) => {
      // Prevent F12, Ctrl+Shift+I, Cmd+Option+I, Ctrl+Shift+J, Cmd+Option+J
      const {key, control, meta, shift, alt} = input;
      if (
        (key === 'F12') ||
        (control && shift && key === 'I') ||
        (meta && alt && key === 'I') ||
        (control && shift && key === 'J') ||
        (meta && alt && key === 'J')
      ) {
        event.preventDefault();
      }
    });

    // Disable context menu (right-click menu)
    contents.on('context-menu', (e, params) => {
      e.preventDefault();
    });
  });

  createWindow();
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});

// Log any unhandled errors
process.on('uncaughtException', (error) => {
  console.error('Uncaught exception:', error);
  logger.error('Uncaught exception:', error);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled rejection at:', promise, 'reason:', reason);
  logger.error('Unhandled rejection:', { reason });
});

// IPC Handlers
ipcMain.handle('smtp:save-config', async (event, config) => {
  try {
    // Make sure secure is a boolean
    if (config.secure === 'true' || config.secure === true) {
      config.secure = true;
    } else {
      config.secure = false;
    }

    // Add a name if not provided
    if (!config.name) {
      config.name = `${config.username}@${config.host}`;
    }

    const validation = validateSmtpConfig(config);
    if (!validation.isValid) {
      return {
        success: false,
        message: 'Validation failed: ' + validation.errors.join(', ')
      };
    }

    // Check for duplicates
    const configs = store.get('smtpConfigs') || [];
    const isDuplicate = configs.some(existingConfig =>
      existingConfig.host === config.host &&
      existingConfig.username === config.username
    );

    if (isDuplicate) {
      return { success: false, message: 'This SMTP configuration already exists' };
    }

    configs.push(config);
    store.set('smtpConfigs', configs);
    return { success: true };
  } catch (error) {
    logger.error('Error saving SMTP config:', error);
    return { success: false, message: error.message };
  }
});

ipcMain.handle('smtp:get-configs', () => {
  try {
    return { success: true, configs: store.get('smtpConfigs') || [] };
  } catch (error) {
    return { success: false, message: error.message };
  }
});

ipcMain.handle('smtp:test-config', async (event, config) => {
  try {
    // Make sure secure is a boolean
    if (config.secure === 'true' || config.secure === true) {
      config.secure = true;
    } else {
      config.secure = false;
    }

    // Override secure setting based on port for common SMTP providers
    const port = parseInt(config.port, 10);
    if (port === 587) {
      config.secure = false;
      console.log('Port 587 detected, setting secure to false (using STARTTLS)');
    } else if (port === 465) {
      config.secure = true;
      console.log('Port 465 detected, setting secure to true (using SSL/TLS)');
    }

    // Validate the config first
    const validation = validateSmtpConfig(config);
    if (!validation.isValid) {
      return {
        success: false,
        message: 'Validation failed: ' + validation.errors.join(', ')
      };
    }

    // Create the transporter with proper timeout settings
    const transporter = nodemailer.createTransport({
      host: config.host,
      port: parseInt(config.port, 10),
      secure: config.secure,
      auth: { user: config.username, pass: config.password },
      connectionTimeout: 10000, // 10 seconds
      greetingTimeout: 10000,   // 10 seconds
      socketTimeout: 15000      // 15 seconds
    });

    // Verify the connection
    await transporter.verify();
    return { success: true, message: 'SMTP connection successful!' };
  } catch (error) {
    logger.error('SMTP test failed:', error);
    return {
      success: false,
      message: `SMTP test failed: ${error.message}`
    };
  }
});

ipcMain.handle('email:send', async (event, { to, fromName, subject, html, config }) => {
  try {
    // Make sure secure is a boolean
    if (config.secure === 'true' || config.secure === true) {
      config.secure = true;
    } else {
      config.secure = false;
    }

    // Override secure setting based on port for common SMTP providers
    const port = parseInt(config.port, 10);
    if (port === 587) {
      config.secure = false;
      console.log('Port 587 detected, setting secure to false (using STARTTLS)');
    } else if (port === 465) {
      config.secure = true;
      console.log('Port 465 detected, setting secure to true (using SSL/TLS)');
    }

    // Create the transporter with proper timeout settings
    const transporter = nodemailer.createTransport({
      host: config.host,
      port: parseInt(config.port, 10),
      secure: config.secure,
      auth: { user: config.username, pass: config.password },
      connectionTimeout: 10000, // 10 seconds
      greetingTimeout: 10000,   // 10 seconds
      socketTimeout: 15000      // 15 seconds
    });

    // Generate a message ID
    const messageId = randomstring.generate({ length: 12, charset: 'alphanumeric' });

    // Send the email
    const result = await transporter.sendMail({
      from: `"${fromName}" <${config.username}>`,
      to,
      subject,
      html,
      messageId: `<${messageId}@${config.host}>`,
      headers: {
        'X-Mailer': 'NodeMailer',
        'X-Priority': '3',
        'X-Spam-Status': 'No, score=0.0',
        'X-Content-Type-Message-Body': '1',
        'Reply-To': config.username,
        'Return-Path': config.username
      }
    });

    return {
      success: true,
      messageId: result.messageId,
      message: `Email sent successfully to ${to}`
    };
  } catch (error) {
    logger.error('Email send failed:', error);
    return {
      success: false,
      message: `Failed to send email: ${error.message}`
    };
  }
});

ipcMain.handle('email:send-batch', async (event, { recipients, templates, smtpConfigs, names, subjects, rotationOptions }) => {
  try {
    // Set the sending flag to true
    isSendingEmails = true;
    cancelSendingRequested = false;

    // Notify the renderer that sending has started
    mainWindow.webContents.send('email:sending-status', { status: 'started', total: recipients.length });
    // Debug: Log the received data
    console.log('email:send-batch received:', {
      recipientsCount: recipients?.length || 0,
      templatesCount: templates?.length || 0,
      smtpConfigsCount: smtpConfigs?.length || 0,
      namesCount: names?.length || 0,
      subjectsCount: subjects?.length || 0,
      rotationOptions: rotationOptions || { batchSize: 100, disableRotation: false }
    });

    // Debug: Log the first SMTP config (with password redacted)
    if (smtpConfigs && smtpConfigs.length > 0) {
      const firstConfig = { ...smtpConfigs[0] };
      if (firstConfig.password) {
        firstConfig.password = '********';
      }
      console.log('First SMTP config:', firstConfig);
    }

    // Validate inputs
    if (!recipients || !Array.isArray(recipients) || recipients.length === 0) {
      return { success: false, message: 'No recipients provided' };
    }

    if (!smtpConfigs || !Array.isArray(smtpConfigs) || smtpConfigs.length === 0) {
      return { success: false, message: 'No SMTP configurations provided' };
    }

    if (!templates || !Array.isArray(templates) || templates.length === 0) {
      return { success: false, message: 'No email templates provided' };
    }

    // Use provided names/subjects or defaults
    const fromNames = names && Array.isArray(names) && names.length > 0 ?
      names : ['Email Sender'];

    const emailSubjects = subjects && Array.isArray(subjects) && subjects.length > 0 ?
      subjects : ['Important Information'];

    let emailCount = 0;
    const results = [];
    let successCount = 0;
    let failureCount = 0;

    for (const recipient of recipients) {
      // Check if cancellation was requested
      if (cancelSendingRequested) {
        console.log('Email sending FORCE STOPPED by user');
        mainWindow.webContents.send('email:sending-status', {
          status: 'cancelled',
          sent: successCount,
          failed: failureCount,
          total: recipients.length,
          message: 'Email campaign was force stopped by user.'
        });
        // Reset the sending flags
        isSendingEmails = false;
        cancelSendingRequested = false;
        break;
      }

      try {
        // Track failed SMTPs for intelligent failover
        const failedSmtps = rotationOptions?.failedSmtps || [];

        // Track current SMTP index for fixed mode
        let currentSmtpIndex = rotationOptions?.currentSmtpIndex !== undefined ?
          rotationOptions.currentSmtpIndex : null;

        // Get current configuration based on rotation options
        const smtpResult = getCurrentSmtpConfig(smtpConfigs, emailCount, {
          batchSize: rotationOptions?.batchSize || 100,
          disableRotation: rotationOptions?.disableRotation || false,
          failedSmtps: failedSmtps,
          currentSmtpIndex: currentSmtpIndex
        });

        // Extract the actual config and update the current index for next time
        const currentConfig = smtpResult.config;
        currentSmtpIndex = smtpResult.index;

        // Log rotation information
        if (smtpResult.disableRotation) {
          console.log(`SMTP Rotation disabled: Using fixed SMTP ${smtpResult.index + 1}/${smtpConfigs.length} (${currentConfig.host}:${currentConfig.port})`);

          if (smtpResult.rotationReason === 'failover') {
            console.log(`Failover activated: Primary SMTP failed, using next available one`);
          } else if (smtpResult.rotationReason === 'all-failed') {
            console.log(`WARNING: All SMTPs have failed. Using the original one anyway.`);
          }
        } else {
          console.log(`SMTP Rotation enabled: ${smtpResult.rotationReason} mode, using SMTP ${smtpResult.index + 1}/${smtpConfigs.length} (${currentConfig.host}:${currentConfig.port})`);
          console.log(`Batch Size: ${smtpResult.batchSize} emails | Current Email: ${emailCount} | Failed Count: ${smtpResult.failedCount}`);

          if (smtpResult.rotationReason === 'failover') {
            console.log(`Failover activated: Skipping failed SMTP and using next available one`);
          } else if (smtpResult.rotationReason === 'all-failed') {
            console.log(`WARNING: All SMTPs have failed twice consecutively. Using base rotation index anyway.`);
          }
        }

        // Get the template for this recipient using the improved rotation logic
        // Templates are now rotated every 50 emails, and rotation is paused if only one template is available
        const template = getCurrentTemplate(templates, emailCount);

        // Log detailed information about template selection
        console.log(`Using template for recipient ${recipient}:`, {
          id: template.id,
          name: template.name || 'Unnamed',
          emailCount,
          rotationIndex: Math.floor(emailCount / 50) % (templates.length > 1 ? templates.length : 1),
          totalTemplates: templates.length
        });

        // Log template details including variables and content preview
        console.log('Template details:', {
          id: template.id,
          name: template.name,
          variables: template.variables || [],
          createdAt: template.createdAt,
          updatedAt: template.updatedAt,
          contentPreview: (template.content || '').substring(0, 50) + '...'
        });

        const fromName = fromNames[emailCount % fromNames.length];
        const subject = emailSubjects[emailCount % emailSubjects.length];

        // Personalize the template with recipient's email
        const templateContent = template.content || template.html || template;

        // Get the email parts for personalization
        const [username, domain] = recipient.split('@');
        const domainName = domain?.split('.')[0] || 'Unknown';
        const toBase64 = (str) => Buffer.from(str).toString('base64');

        // Generate random strings that are consistent for this template
        // Use the template name or ID as a seed to ensure consistency
        const templateId = template.id || template.name || 'default';
        const seed = `${templateId}-${emailCount}`;

        // Use the seed to generate consistent random strings for this template
        // We'll use a deterministic approach based on the template and recipient
        // This ensures the same variables are used for all placeholders in the template
        const getRandomString = (length, base) => {
          const chars = 'abcdefghijklmnopqrstuvwxyz';
          let result = '';
          const baseStr = base + recipient.substring(0, 3);

          for (let i = 0; i < length; i++) {
            // Use a deterministic approach to generate the string
            const charIndex = (baseStr.charCodeAt(i % baseStr.length) + i) % chars.length;
            result += chars.charAt(charIndex);
          }

          return result;
        };

        // Generate consistent random strings for this template
        const randomShort = getRandomString(5, seed);
        const randomLong = getRandomString(50, seed);

        const recipientBase64 = toBase64(recipient);
        const capitalizedDomain = domainName ? domainName.charAt(0).toUpperCase() + domainName.slice(1) : '';
        // Create a map of all possible placeholder formats
        const placeholders = {
          // Standard format
          'GIRLUSER': username || '',
          'GIRLDOMC': capitalizedDomain,
          'GIRLdomain': domainName || '',
          'GIRLDOMAIN': domain || '',
          'TECHGIRLEMAIL': recipient,
          'TECHGIRLEMAIL64': recipientBase64,
          'TECHGIRLRND': randomShort,
          'TECHGIRLRNDLONG': randomLong,

          // With brackets format
          '{GIRLUSER}': username || '',
          '{GIRLDOMC}': capitalizedDomain,
          '{GIRLdomain}': domainName || '',
          '{GIRLDOMAIN}': domain || '',
          '{TECHGIRLEMAIL}': recipient,
          '{TECHGIRLEMAIL64}': recipientBase64,
          '{TECHGIRLRND}': randomShort,
          '{TECHGIRLRNDLONG}': randomLong,

          // With %% format
          '%%GIRLUSER%%': username || '',
          '%%GIRLDOMC%%': capitalizedDomain,
          '%%GIRLdomain%%': domainName || '',
          '%%GIRLDOMAIN%%': domain || '',
          '%%TECHGIRLEMAIL%%': recipient,
          '%%TECHGIRLEMAIL64%%': recipientBase64,
          '%%TECHGIRLRND%%': randomShort,
          '%%TECHGIRLRNDLONG%%': randomLong,
        };

        // Log the placeholder values for debugging
        console.log(`Placeholder values for template "${template.name || 'Unnamed'}" and recipient ${recipient}:`);
        console.log({
          GIRLUSER: username || '',
          GIRLDOMC: capitalizedDomain,
          GIRLdomain: domainName || '',
          GIRLDOMAIN: domain || '',
          TECHGIRLEMAIL: recipient,
          TECHGIRLEMAIL64: recipientBase64.substring(0, 10) + '...',
          TECHGIRLRND: randomShort,  // This will be consistent for the same template
          TECHGIRLRNDLONG: randomShort + '...'  // This will be consistent for the same template
        });

        // Replace all placeholders in the template
        let personalizedContent = templateContent;
        for (const [placeholder, value] of Object.entries(placeholders)) {
          personalizedContent = personalizedContent.split(placeholder).join(value);
        }

        // Also handle case-insensitive replacements for any remaining placeholders
        const remainingPlaceholders = [
          'GIRLUSER', 'GIRLDOMC', 'GIRLdomain', 'GIRLDOMAIN',
          'TECHGIRLEMAIL', 'TECHGIRLEMAIL64', 'TECHGIRLRND', 'TECHGIRLRNDLONG'
        ];

        for (const placeholder of remainingPlaceholders) {
          const regex = new RegExp(placeholder, 'gi');
          const value = placeholders[placeholder];
          if (value) { // Only replace if we have a value
            personalizedContent = personalizedContent.replace(regex, value);
          }
        }

        // Log a sample of the personalized content
        const contentPreview = personalizedContent.substring(0, 100).replace(/\n/g, ' ');
        console.log(`Personalized content preview for ${recipient}: ${contentPreview}...`);

        // Log the personalization for debugging
        console.log(`Personalized template for ${recipient}. Original: "${templateContent.substring(0, 50)}..." -> Personalized: "${personalizedContent.substring(0, 50)}..."`);

        // Check again if cancellation was requested before sending
        if (cancelSendingRequested) {
          console.log(`Skipping email to ${recipient} due to force stop request`);
          break;
        }

        // Send the email with personalized content
        const messageId = await sendEmail(
          currentConfig,
          recipient,
          fromName,
          subject,
          personalizedContent
        );

        results.push({ recipient, messageId, success: true });
        emailCount++;
        successCount++; // Increment success count

        // Add a random delay between emails (1-5 seconds)
        const delay = Math.floor(Math.random() * 4000) + 1000;

        // Send progress update with delay information
        mainWindow.webContents.send('email:progress', {
          current: emailCount,
          total: recipients.length,
          success: true,
          recipient,
          sent: successCount,
          failed: failureCount,
          delayTime: delay / 1000 // Convert to seconds
        });

        // Now wait for the delay
        await new Promise(resolve => setTimeout(resolve, delay));

        // Add a small delay to allow the UI to update
        await new Promise(resolve => setTimeout(resolve, 100));
      } catch (error) {
        logger.error(`Failed to send email to ${recipient}:`, error);

        // Track SMTP failures for failover logic
        if (currentConfig) {
          // Add the failed SMTP to the list
          failedSmtps.push({
            host: currentConfig.host,
            username: currentConfig.username,
            port: currentConfig.port
          });

          // Log the failure
          console.log(`SMTP failure detected: ${currentConfig.host}:${currentConfig.port} (${currentConfig.username})`);
          const failureCount = failedSmtps.filter(smtp =>
            smtp.host === currentConfig.host &&
            smtp.username === currentConfig.username
          ).length;
          console.log(`This SMTP has failed ${failureCount} times`);

          // Calculate the next SMTP index for failover
          let nextSmtpIndex = null;
          if (failureCount >= 2) {
            // If we're in fixed mode or this SMTP has failed twice, calculate the next index
            nextSmtpIndex = (currentSmtpIndex + 1) % smtpConfigs.length;
            console.log(`Failover will use next SMTP index: ${nextSmtpIndex}`);
          }
        }

        results.push({
          recipient,
          success: false,
          error: error.message,
          smtpConfig: currentConfig ? {
            host: currentConfig.host,
            username: currentConfig.username,
            port: currentConfig.port
          } : null,
          nextSmtpIndex: nextSmtpIndex
        });
        failureCount++;

        // Send progress update
        mainWindow.webContents.send('email:progress', {
          current: emailCount,
          total: recipients.length,
          success: false,
          recipient,
          error: error.message,
          sent: successCount,
          failed: failureCount,
          smtpConfig: currentConfig ? {
            host: currentConfig.host,
            username: currentConfig.username,
            port: currentConfig.port
          } : null,
          nextSmtpIndex: nextSmtpIndex
        });

        // Add a small delay to allow the UI to update
        await new Promise(resolve => setTimeout(resolve, 100));
      }
    }

    // Reset the sending flags
    isSendingEmails = false;
    cancelSendingRequested = false;

    // Notify the renderer that sending has completed
    mainWindow.webContents.send('email:sending-status', {
      status: 'completed',
      sent: successCount,
      failed: failureCount,
      total: recipients.length
    });

    return {
      success: true,
      results,
      stats: {
        total: recipients.length,
        sent: emailCount,
        success: successCount,
        failed: failureCount
      }
    };
  } catch (error) {
    // Reset the sending flags
    isSendingEmails = false;
    cancelSendingRequested = false;

    // Notify the renderer that sending has failed
    mainWindow.webContents.send('email:sending-status', {
      status: 'error',
      error: error.message,
      total: recipients?.length || 0
    });

    logger.error('Batch email sending failed:', error);
    return { success: false, message: error.message };
  }
});

// Template handlers
ipcMain.handle('template:save', async (event, data) => {
  console.log('template:save handler called with data:', data);
  try {
    // Check if data is properly formatted
    if (!data || typeof data !== 'object') {
      console.error('Invalid data format:', data);
      return { success: false, message: 'Invalid data format' };
    }

    const { name, content, variables } = data;

    if (!name || !content) {
      console.error('Missing required fields:', { name, content });
      return { success: false, message: 'Template name and content are required' };
    }

    // Get current templates and validate the array
    let templates = templateStore.get('templates') || [];
    if (!Array.isArray(templates)) {
      console.warn('Templates is not an array, resetting to empty array');
      templates = [];
    }

    console.log('Current templates:', templates);

    // Check if a template with the same name already exists
    const existingTemplateIndex = templates.findIndex(t => t.name === name);
    const newTemplate = {
      id: Date.now(),
      name,
      content,
      variables,
      createdAt: new Date().toISOString()
    };

    if (existingTemplateIndex !== -1) {
      // Update existing template
      console.log(`Updating existing template with name: ${name}`);
      templates[existingTemplateIndex] = {
        ...templates[existingTemplateIndex],
        ...newTemplate,
        updatedAt: new Date().toISOString()
      };
    } else {
      // Add new template
      templates.push(newTemplate);
    }

    // Save templates back to store
    templateStore.set('templates', templates);

    console.log('Template saved successfully:', newTemplate);
    return { success: true, template: newTemplate };
  } catch (error) {
    console.error('Failed to save template:', error);
    logger.error('Failed to save template:', error);
    return { success: false, message: error.message };
  }
});

ipcMain.handle('template:get-all', () => {
  console.log('template:get-all handler called');
  try {
    // Get templates and validate the array
    let templates = templateStore.get('templates') || [];
    if (!Array.isArray(templates)) {
      console.warn('Templates is not an array, resetting to empty array');
      templates = [];
      templateStore.set('templates', templates);
    }

    // Sort templates by creation date (newest first)
    templates.sort((a, b) => {
      const dateA = a.createdAt ? new Date(a.createdAt) : new Date(0);
      const dateB = b.createdAt ? new Date(b.createdAt) : new Date(0);
      return dateB - dateA;
    });

    console.log('Retrieved templates:', templates);
    return { success: true, templates };
  } catch (error) {
    console.error('Failed to get templates:', error);
    logger.error('Failed to get templates:', error);
    return { success: false, message: error.message };
  }
});

ipcMain.handle('template:delete', (event, templateId) => {
  console.log('template:delete handler called with id:', templateId);
  try {
    // Get templates and validate the array
    let templates = templateStore.get('templates') || [];
    if (!Array.isArray(templates)) {
      console.warn('Templates is not an array, resetting to empty array');
      templates = [];
      templateStore.set('templates', templates);
      return { success: true, message: 'No templates to delete' };
    }

    console.log('Current templates before delete:', templates);

    // Check if the template exists
    const templateToDelete = templates.find(template => template.id === templateId);
    if (!templateToDelete) {
      console.warn(`Template with id ${templateId} not found`);
      return { success: false, message: 'Template not found' };
    }

    // Remove the template
    const updatedTemplates = templates.filter(template => template.id !== templateId);
    templateStore.set('templates', updatedTemplates);

    console.log('Templates after delete:', updatedTemplates);
    return {
      success: true,
      deletedTemplate: templateToDelete,
      remainingCount: updatedTemplates.length
    };
  } catch (error) {
    console.error('Failed to delete template:', error);
    logger.error('Failed to delete template:', error);
    return { success: false, message: error.message };
  }
});

ipcMain.handle('template:load', async (event, templatePath) => {
  try {
    const content = await fs.readFile(templatePath, 'utf8');
    return { success: true, content };
  } catch (error) {
    logger.error(`Failed to load template from ${templatePath}:`, error);
    return { success: false, message: error.message };
  }
});

ipcMain.handle('template:personalize', (event, { template, email }) => {
  try {
    if (!template) return { success: false, message: 'No template provided' };
    if (!email) return { success: false, message: 'No email provided' };

    const [username, domain] = email.split('@');
    let domainName = '';
    let domainExt = '';

    if (domain) {
      // Handle domains with or without dots
      if (domain.includes('.')) {
        const domainParts = domain.split('.');
        domainName = domainParts[0];
        domainExt = domainParts.slice(1).join('.');
      } else {
        // For domains without dots (like localhost)
        domainName = domain;
      }
    }

    const toBase64 = (str) => Buffer.from(str).toString('base64');

    // Generate random strings
    const randomShort = randomstring.generate({ length: 5, charset: 'alphabetic' });
    const randomLong = randomstring.generate({ length: 50, charset: 'alphabetic' });

    const personalized = template
      .replace(/GIRLUSER/g, username || '')
      .replace(/GIRLDOMC/g, domainName.toUpperCase() || '')
      .replace(/GIRLdomain/g, domainName || '')
      .replace(/GIRLDOMAIN/g, domain || '')
      .replace(/TECHGIRLEMAIL/g, email)
      .replace(/TECHGIRLEMAIL64/g, toBase64(email))
      .replace(/TECHGIRLRND/g, randomShort)
      .replace(/TECHGIRLRNDLONG/g, randomLong);

    return { success: true, content: personalized };
  } catch (error) {
    logger.error('Failed to personalize template:', error);
    return { success: false, message: error.message };
  }
});

// Cancel email sending handler
ipcMain.handle('email:cancel-sending', () => {
  if (isSendingEmails) {
    // Set the cancellation flag
    cancelSendingRequested = true;

    // Notify the renderer that cancellation has been requested
    mainWindow.webContents.send('email:sending-status', {
      status: 'cancelling',
      message: 'Force stopping email campaign...'
    });

    // Log the cancellation request
    console.log('FORCE STOP requested by user - email sending will be cancelled');

    return { success: true, message: 'Force stop requested' };
  } else {
    return { success: false, message: 'No email sending in progress' };
  }
});

// Recipient list management handlers
ipcMain.handle('recipients:save-list', async (event, { name, recipients }) => {
  try {
    if (!name) {
      return { success: false, message: 'List name is required' };
    }

    if (!recipients || !Array.isArray(recipients) || recipients.length === 0) {
      return { success: false, message: 'No recipients provided' };
    }

    // Get existing lists
    const lists = store.get('recipientLists') || [];

    // Check if we already have 2 lists and this would be a new one
    const existingListIndex = lists.findIndex(list => list.name === name);
    if (lists.length >= 2 && existingListIndex === -1) {
      return { success: false, message: 'Maximum of 2 recipient lists allowed. Please delete one first.' };
    }

    // Update or add the list
    if (existingListIndex !== -1) {
      lists[existingListIndex] = { name, recipients };
    } else {
      lists.push({ name, recipients });
    }

    // Save to store
    store.set('recipientLists', lists);

    return { success: true, message: 'Recipient list saved successfully' };
  } catch (error) {
    console.error('Failed to save recipient list:', error);
    return { success: false, message: error.message };
  }
});

ipcMain.handle('recipients:get-lists', () => {
  try {
    const lists = store.get('recipientLists') || [];
    return { success: true, lists };
  } catch (error) {
    console.error('Failed to get recipient lists:', error);
    return { success: false, message: error.message };
  }
});

ipcMain.handle('recipients:delete-list', (event, listName) => {
  try {
    if (!listName) {
      return { success: false, message: 'List name is required' };
    }

    // Get existing lists
    const lists = store.get('recipientLists') || [];

    // Filter out the list to delete
    const updatedLists = lists.filter(list => list.name !== listName);

    // Save to store
    store.set('recipientLists', updatedLists);

    return { success: true, message: 'Recipient list deleted successfully' };
  } catch (error) {
    console.error('Failed to delete recipient list:', error);
    return { success: false, message: error.message };
  }
});

// URL Encoder handler
ipcMain.handle('url:encode', async (event, url) => {
  try {
    if (!url) {
      return { success: false, message: 'URL is required' };
    }

    // Use the JavaScript implementation from urlencode.js
    // Try multiple possible locations for the file
    let urlEncodePath;
    let encodeModule;

    try {
      // First try the app directory
      urlEncodePath = path.join(__dirname, 'urlencode.js');
      console.log('Trying URL encoder from:', urlEncodePath);
      encodeModule = require(urlEncodePath);
    } catch (err) {
      try {
        // Then try the extraResources directory (for packaged app)
        if (app && app.getAppPath) {
          const appPath = app.getAppPath();
          urlEncodePath = path.join(appPath, '..', 'urlencode.js');
          console.log('Trying URL encoder from extraResources:', urlEncodePath);
          encodeModule = require(urlEncodePath);
        } else {
          throw new Error('Could not determine app path');
        }
      } catch (err2) {
        // Fallback to a simple implementation if the file can't be found
        console.error('Could not load urlencode.js, using fallback implementation');
        encodeModule = {
          encodeHtmlEntities: (url) => {
            if (!url) return '';
            return Array.from(url).map(char => `&#${char.charCodeAt(0)};`).join('');
          }
        };
      }
    }

    const { encodeHtmlEntities } = encodeModule;
    const encodedUrl = encodeHtmlEntities(url);

    return {
      success: true,
      originalUrl: url,
      encodedUrl: encodedUrl
    };
  } catch (error) {
    console.error('Failed to encode URL:', error);
    return { success: false, message: error.message };
  }
});

// SMTP config deletion handler
ipcMain.handle('smtp:delete-config', (event, configName) => {
  try {
    const configs = store.get('smtpConfigs') || [];
    const updatedConfigs = configs.filter(config => config.name !== configName);
    store.set('smtpConfigs', updatedConfigs);
    return { success: true };
  } catch (error) {
    logger.error('Failed to delete SMTP config:', error);
    return { success: false, message: error.message };
  }
});

// Expose Electron API to renderer process
contextBridge.exposeInMainWorld('electronAPI', {
    onSendingStatus: (callback) => ipcRenderer.on('sending-status', callback),
    offSendingStatus: (callback) => ipcRenderer.off('sending-status', callback),
    onEmailProgress: (callback) => ipcRenderer.on('email-progress', callback),
    offEmailProgress: (callback) => ipcRenderer.off('email-progress', callback),
    cancelSendingEmails: () => ipcRenderer.invoke('cancel-sending-emails')
});