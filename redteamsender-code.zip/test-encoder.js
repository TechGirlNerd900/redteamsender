/**
 * Test script for the URL encoder
 * Run this with: node test-encoder.js
 */

const path = require('path');
const fs = require('fs');

// Try to find and load the urlencode.js file
let encoderPath;
let encodeModule;

// List of possible locations to check
const possiblePaths = [
  path.join(__dirname, 'urlencode.js'),
  path.join(__dirname, '..', 'urlencode.js'),
  path.join(__dirname, '..', 'resources', 'urlencode.js')
];

// Try each path
for (const testPath of possiblePaths) {
  console.log(`Checking for urlencode.js at: ${testPath}`);
  if (fs.existsSync(testPath)) {
    encoderPath = testPath;
    console.log(`Found urlencode.js at: ${encoderPath}`);
    break;
  }
}

if (encoderPath) {
  try {
    encodeModule = require(encoderPath);
    console.log('Successfully loaded the encoder module');
    
    // Test the encoder
    const testUrl = 'https://example.com/?param=value&another=123';
    const encoded = encodeModule.encodeHtmlEntities(testUrl);
    
    console.log('\nTest Results:');
    console.log('Original URL:', testUrl);
    console.log('Encoded URL:', encoded);
    console.log('\nEncoder is working correctly!');
  } catch (err) {
    console.error('Error loading the encoder module:', err);
  }
} else {
  console.error('Could not find urlencode.js in any of the expected locations');
}
