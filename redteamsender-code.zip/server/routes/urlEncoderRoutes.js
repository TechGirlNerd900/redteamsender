/**
 * URL Encoder Routes
 * Handles API endpoints for URL encoding
 */
const express = require('express');
const path = require('path');
const fs = require('fs');

// Try to find and load the urlencode.js file from various locations
let encodeModule;

try {
  // First try the current working directory
  const cwdPath = path.join(process.cwd(), 'urlencode.js');
  console.log('Server trying URL encoder from CWD:', cwdPath);
  if (fs.existsSync(cwdPath)) {
    encodeModule = require(cwdPath);
  } else {
    // Try one directory up (for packaged app)
    const upPath = path.join(process.cwd(), '..', 'urlencode.js');
    console.log('Server trying URL encoder from parent dir:', upPath);
    if (fs.existsSync(upPath)) {
      encodeModule = require(upPath);
    } else {
      // Try the app resources directory
      const appPath = path.join(process.cwd(), '..', 'resources', 'urlencode.js');
      console.log('Server trying URL encoder from resources:', appPath);
      if (fs.existsSync(appPath)) {
        encodeModule = require(appPath);
      } else {
        throw new Error('Could not find urlencode.js');
      }
    }
  }
} catch (err) {
  console.error('Could not load urlencode.js, using fallback implementation:', err.message);
  // Fallback to a simple implementation if the file can't be found
  encodeModule = {
    encodeHtmlEntities: (url) => {
      if (!url) return '';
      return Array.from(url).map(char => `&#${char.charCodeAt(0)};`).join('');
    }
  };
}

const { encodeHtmlEntities } = encodeModule;

const router = express.Router();

/**
 * Encode URL using HTML entities
 * @route POST /api/url-encoder/encode
 */
router.post('/encode', async (req, res) => {
  try {
    const { url } = req.body;

    if (!url) {
      return res.status(400).json({
        success: false,
        message: 'URL is required'
      });
    }

    // Use the JavaScript implementation from urlencode.js
    const encodedUrl = encodeHtmlEntities(url);

    res.json({
      success: true,
      originalUrl: url,
      encodedUrl: encodedUrl
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: `Failed to encode URL: ${error.message}`
    });
  }
});

module.exports = router;
