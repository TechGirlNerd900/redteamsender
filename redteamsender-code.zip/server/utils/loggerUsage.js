// No changes needed, already using CommonJS
