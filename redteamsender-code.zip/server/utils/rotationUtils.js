/**
 * Rotation Utilities
 * Handles rotation of SMTP configurations and templates
 */

/**
 * Gets the current SMTP configuration based on email count and rotation settings
 * Implements both global batch rotation and fixed SMTP with failover modes
 *
 * @param {Array} smtpConfigs - Array of SMTP configurations
 * @param {number} emailCount - Current email count
 * @param {Object} options - SMTP rotation options
 * @param {number} options.batchSize - Number of emails before rotating (50, 100, 200, 400, or 800)
 * @param {boolean} options.disableRotation - Whether to disable rotation and use only the first SMTP
 * @param {Array} options.failedSmtps - Array of SMTP configs that have failed consecutively
 * @param {number} options.currentSmtpIndex - Current SMTP index (for fixed mode)
 * @returns {Object} - Current SMTP configuration and metadata
 */
const getCurrentSmtpConfig = (smtpConfigs, emailCount, options = {}) => {
  if (!smtpConfigs || !Array.isArray(smtpConfigs) || smtpConfigs.length === 0) {
    throw new Error('No SMTP configurations available');
  }

  // Default options
  const {
    batchSize = 100,
    disableRotation = false,
    failedSmtps = [],
    currentSmtpIndex = null
  } = options;

  // Validate batch size (must be one of the allowed values)
  const validBatchSizes = [50, 100, 200, 400, 800];
  const normalizedBatchSize = validBatchSizes.includes(batchSize) ? batchSize : 100;

  // Create a map of failed SMTPs for quick lookup
  const failedSmtpMap = new Map();

  // Group failures by SMTP to count consecutive failures
  failedSmtps.forEach(smtp => {
    const key = `${smtp.host}:${smtp.port}:${smtp.username}`;
    const count = failedSmtpMap.get(key) || 0;
    failedSmtpMap.set(key, count + 1);
  });

  let selectedIndex;
  let rotationReason;
  let attemptsCount = 0;

  // Handle the "Disable SMTP Rotation" mode
  if (disableRotation) {
    // If we have a current SMTP index and it's valid, use it
    if (currentSmtpIndex !== null && currentSmtpIndex >= 0 && currentSmtpIndex < smtpConfigs.length) {
      selectedIndex = currentSmtpIndex;
      rotationReason = 'fixed';
    } else {
      // Otherwise, use the first SMTP config
      selectedIndex = 0;
      rotationReason = 'fixed-initial';
    }

    // Check if the selected SMTP has failed consecutively
    const selectedSmtp = smtpConfigs[selectedIndex];
    const key = `${selectedSmtp.host}:${selectedSmtp.port}:${selectedSmtp.username}`;
    const failureCount = failedSmtpMap.get(key) || 0;

    // If the SMTP has failed twice consecutively, move to the next one
    if (failureCount >= 2) {
      console.log(`SMTP ${selectedSmtp.host}:${selectedSmtp.port} (${selectedSmtp.username}) has failed ${failureCount} times consecutively. Failing over to next SMTP.`);
      selectedIndex = (selectedIndex + 1) % smtpConfigs.length;
      rotationReason = 'failover';

      // Check if the new SMTP has also failed
      let nextFailureCount = 0;
      let nextAttempts = 0;

      // Try to find a working SMTP
      while (nextAttempts < smtpConfigs.length - 1) {  // -1 because we already tried the initial one
        const nextSmtp = smtpConfigs[selectedIndex];
        const nextKey = `${nextSmtp.host}:${nextSmtp.port}:${nextSmtp.username}`;
        nextFailureCount = failedSmtpMap.get(nextKey) || 0;

        // If this SMTP has failed less than twice, use it
        if (nextFailureCount < 2) {
          break;
        }

        // Otherwise, try the next SMTP
        console.log(`Next SMTP ${nextSmtp.host}:${nextSmtp.port} (${nextSmtp.username}) has also failed ${nextFailureCount} times. Continuing failover.`);
        selectedIndex = (selectedIndex + 1) % smtpConfigs.length;
        nextAttempts++;
      }

      // If we've tried all SMTPs and they've all failed, use the original one anyway
      if (nextAttempts === smtpConfigs.length - 1) {
        console.log('All SMTPs have failed. Using the original one anyway.');
        selectedIndex = currentSmtpIndex !== null ? currentSmtpIndex : 0;
        rotationReason = 'all-failed';
      }
    }
  } else {
    // Normal batch rotation mode
    // Calculate the base index from email count and batch size
    const baseIndex = Math.floor(emailCount / normalizedBatchSize) % smtpConfigs.length;

    // Find a working SMTP starting from the base index
    selectedIndex = baseIndex;
    rotationReason = 'batch';

    // Try to find a working SMTP (one that hasn't failed twice consecutively)
    while (attemptsCount < smtpConfigs.length) {
      const smtp = smtpConfigs[selectedIndex];
      const key = `${smtp.host}:${smtp.port}:${smtp.username}`;
      const failureCount = failedSmtpMap.get(key) || 0;

      // If this SMTP has failed less than twice, use it
      if (failureCount < 2) {
        break;
      }

      // Otherwise, try the next SMTP
      console.log(`SMTP ${smtp.host}:${smtp.port} (${smtp.username}) has failed ${failureCount} times consecutively. Skipping.`);
      selectedIndex = (selectedIndex + 1) % smtpConfigs.length;
      rotationReason = 'failover';
      attemptsCount++;
    }

    // If we've tried all SMTPs and they've all failed twice, use the base index anyway
    if (attemptsCount === smtpConfigs.length) {
      console.log('All SMTPs have failed twice consecutively. Using the base rotation index anyway.');
      selectedIndex = baseIndex;
      rotationReason = 'all-failed';
    }
  }

  // Get the selected SMTP
  const selectedSmtp = smtpConfigs[selectedIndex];
  const key = `${selectedSmtp.host}:${selectedSmtp.port}:${selectedSmtp.username}`;

  // Return the selected SMTP config along with metadata
  return {
    config: selectedSmtp,
    index: selectedIndex,
    rotationReason,
    batchSize: normalizedBatchSize,
    disableRotation,
    failedCount: failedSmtpMap.get(key) || 0
  };
};

/**
 * Gets the current template based on email count
 * Rotates templates every 50 emails
 * If only one template is available, rotation is paused
 * @param {Array} templates - Array of email templates
 * @param {number} emailCount - Current email count
 * @returns {Object} - Current template
 */
const getCurrentTemplate = (templates, emailCount) => {
  // Validate templates array
  if (!templates || !Array.isArray(templates)) {
    throw new Error('Invalid templates array');
  }

  // Filter out any invalid templates
  const validTemplates = templates.filter(template =>
    template && (typeof template === 'object' || typeof template === 'string')
  );

  // Check if we have any valid templates
  if (validTemplates.length === 0) {
    throw new Error('No valid templates available');
  }

  // If only one template is available, always use it (pause rotation)
  if (validTemplates.length === 1) {
    console.log('Only one template available, using it for all emails');
    return validTemplates[0];
  }

  // Rotate template every 50 emails
  const rotationInterval = 50;
  const index = Math.floor(emailCount / rotationInterval) % validTemplates.length;

  console.log(`Template rotation: Using template index ${index} (${validTemplates.length} templates available)`);
  return validTemplates[index];
};

/**
 * Rotates SMTP configurations based on the selected mode (batch rotation or fixed with failover)
 * @param {Array} configs - Array of SMTP configurations
 * @param {number} emailCount - Current email count
 * @param {Object} options - Rotation options
 * @param {number} options.batchSize - Number of emails before rotating (50, 100, 200, 400, or 800)
 * @param {boolean} options.disableRotation - Whether to disable rotation and use only the first SMTP
 * @param {Array} options.failedSmtps - Array of SMTP configs that have failed consecutively
 * @param {number} options.currentSmtpIndex - Current SMTP index (for fixed mode)
 * @returns {Object} - Object containing the next SMTP configuration and metadata
 */
const rotateSmtp = (configs, emailCount = 0, options = {}) => {
  if (!configs || !Array.isArray(configs) || configs.length === 0) {
    throw new Error('No SMTP configurations available');
  }

  // Get the current SMTP configuration using the enhanced logic
  const result = getCurrentSmtpConfig(configs, emailCount, options);

  // Log rotation information
  console.log(`SMTP Rotation: ${result.rotationReason} mode, using SMTP ${result.index + 1}/${configs.length} (${result.config.host}:${result.config.port})`);

  if (result.disableRotation) {
    console.log(`SMTP Rotation disabled: Using fixed SMTP with failover after 2 consecutive failures`);

    if (result.rotationReason === 'failover') {
      console.log(`Failover activated: Primary SMTP failed, using next available one`);
    } else if (result.rotationReason === 'all-failed') {
      console.log(`WARNING: All SMTPs have failed. Using the original one anyway.`);
    }
  } else {
    console.log(`SMTP Rotation enabled: Batch Size: ${result.batchSize} emails | Current Email: ${emailCount} | Failed Count: ${result.failedCount}`);

    if (result.rotationReason === 'failover') {
      console.log(`Failover activated: Skipping failed SMTP and using next available one`);
    } else if (result.rotationReason === 'all-failed') {
      console.log(`WARNING: All SMTPs have failed twice consecutively. Using base rotation index anyway.`);
    }
  }

  return result;
};


module.exports = {
    getCurrentSmtpConfig,
    getCurrentTemplate,
    rotateSmtp
};