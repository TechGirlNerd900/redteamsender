import React, { useState, useEffect } from 'react';
import '../styles/SMTPConfig.css';
import {
  FaPlus,
  FaEdit,
  FaTrash,
  FaCheck,
  FaQuestion,
  FaExchangeAlt,
  FaLock,
  FaChevronDown,
  FaChevronUp,
  FaInfoCircle,
  FaServer,
  FaCog
} from 'react-icons/fa';
import Modal from './Modal';

const SMTPConfig = ({ onConfigSave, onRotationOptionsChange }) => {
  const [configs, setConfigs] = useState([]);
  const [error, setError] = useState(null);
  const [newConfig, setNewConfig] = useState({
    name: '',
    host: '',
    port: '',
    username: '',
    password: '',
    secure: false,

    status: 'Not Tested' // Status field
  });

  // SMTP rotation options
  const [rotationOptions, setRotationOptions] = useState({
    batchSize: 100, // Default batch size
    disableRotation: false // Default rotation mode
  });
  const [isLoading, setIsLoading] = useState(false);
  const [showForm, setShowForm] = useState(false); // Control form visibility
  const [editMode, setEditMode] = useState(false); // Track if we're editing
  const [editingConfigName, setEditingConfigName] = useState(null); // Track which config is being edited

  // New state variables for UI improvements
  const [showAdvancedSettings, setShowAdvancedSettings] = useState(false);
  const [expandedConfigs, setExpandedConfigs] = useState({});
  const [modalState, setModalState] = useState({
    isOpen: false,
    title: '',
    message: '',
    type: 'info'
  });

  const loadConfigs = async () => {
    setIsLoading(true);
    try {
      const result = await window.electronAPI.getSmtpConfigs();
      if (result.success) {
        setConfigs(result.configs);
        // Pass the configs to the parent component
        if (onConfigSave && typeof onConfigSave === 'function') {
          onConfigSave(result.configs);
        }
        setError(null);
      } else {
        setError(result.message);
      }
    } catch (err) {
      setError('Failed to load SMTP configurations');
    } finally {
      setIsLoading(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setNewConfig(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleSaveConfig = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    try {
      // Prepare the config to save
      const configToSave = {
        ...newConfig,
        status: 'Not Tested' // Always set status to Not Tested when saving
      };

      // If we're in edit mode, we need to delete the old config first
      if (editMode && editingConfigName) {
        await window.electronAPI.deleteSmtpConfig(editingConfigName);
      }

      const result = await window.electronAPI.saveSmtpConfig(configToSave);
      if (result.success) {
        // Load the updated configs
        const configsResult = await window.electronAPI.getSmtpConfigs();
        if (configsResult.success) {
          setConfigs(configsResult.configs);
          // Pass the updated configs to the parent component
          if (onConfigSave && typeof onConfigSave === 'function') {
            onConfigSave(configsResult.configs);
          }
        }

        // Reset the form
        setNewConfig({
          name: '',
          host: '',
          port: '',
          username: '',
          password: '',
          secure: false,
          status: 'Not Tested'
        });
        // Hide the form after successful save
        setShowForm(false);
        setEditMode(false);
        setEditingConfigName(null);
      } else {
        setError(result.message || 'Failed to save configuration');
      }
    } catch (err) {
      setError('Failed to save SMTP configuration: ' + err.message);
    } finally {
      setIsLoading(false);
    }
  };

  const handleEditConfig = (config) => {
    // Set the form to edit mode
    setEditMode(true);
    setEditingConfigName(config.name);

    // Populate the form with the config data
    setNewConfig({
      ...config,
      // Don't show the actual password, but require it to be re-entered
      password: ''
    });

    // Show the form
    setShowForm(true);
  };

  const handleDeleteConfig = async (name) => {
    if (!window.confirm('Are you sure you want to delete this configuration?')) {
      return;
    }

    setIsLoading(true);
    try {
      const result = await window.electronAPI.deleteSmtpConfig(name);
      if (result.success) {
        // Load the updated configs
        const configsResult = await window.electronAPI.getSmtpConfigs();
        if (configsResult.success) {
          setConfigs(configsResult.configs);
          // Pass the updated configs to the parent component
          if (onConfigSave && typeof onConfigSave === 'function') {
            onConfigSave(configsResult.configs);
          }
        }
      } else {
        setError(result.message || 'Failed to delete configuration');
      }
    } catch (err) {
      setError('Failed to delete SMTP configuration');
    } finally {
      setIsLoading(false);
    }
  };

  // Function for testing SMTP configurations
  const handleTestConfig = async (config) => {
    setIsLoading(true);
    try {
      // Check if using Gmail with port 587 and secure:true (common mistake)
      if (config.host.includes('gmail.com') && config.port === '587' && config.secure === true) {
        // Automatically fix the configuration
        const fixedConfig = { ...config, secure: false };
        console.log('Fixing Gmail configuration - changing secure from true to false for port 587');

        // Test the fixed configuration
        const result = await window.electronAPI.testSmtpConfig(fixedConfig);
        if (result.success) {
          // Update the config status to Verified
          const updatedConfigs = configs.map(c => {
            if (c.name === config.name) {
              return { ...fixedConfig, status: 'Verified' };
            }
            return c;
          });
          setConfigs(updatedConfigs);

          // Save the updated status to the store
          const updatedConfig = { ...fixedConfig, status: 'Verified' };
          await window.electronAPI.saveSmtpConfig(updatedConfig);

          // Load the updated configs to pass to the parent component
          const configsResult = await window.electronAPI.getSmtpConfigs();
          if (configsResult.success && onConfigSave && typeof onConfigSave === 'function') {
            onConfigSave(configsResult.configs);
          }

          // Show success modal
          showModal(
            'SMTP Test Successful',
            'Connection to SMTP server was successful! Note: We automatically set secure=false for Gmail port 587.',
            'success'
          );
        } else {
          // Show error modal
          showModal(
            'SMTP Test Failed',
            result.message,
            'error'
          );
        }
      } else {
        // Normal test flow
        const result = await window.electronAPI.testSmtpConfig(config);
        if (result.success) {
          // Update the config status to Verified
          const updatedConfigs = configs.map(c => {
            if (c.name === config.name) {
              return { ...c, status: 'Verified' };
            }
            return c;
          });
          setConfigs(updatedConfigs);

          // Save the updated status to the store
          const updatedConfig = { ...config, status: 'Verified' };
          await window.electronAPI.saveSmtpConfig(updatedConfig);

          // Load the updated configs to pass to the parent component
          const configsResult = await window.electronAPI.getSmtpConfigs();
          if (configsResult.success && onConfigSave && typeof onConfigSave === 'function') {
            onConfigSave(configsResult.configs);
          }

          // Show success modal
          showModal(
            'SMTP Test Successful',
            'Connection to SMTP server was successful!',
            'success'
          );
        } else {
          // Format error message based on common issues
          let errorMessage = result.message;

          if (result.message.includes('WRONG_VERSION_NUMBER')) {
            errorMessage = 'SSL/TLS configuration error. If using port 587, try setting "secure" to false. If using port 465, set "secure" to true.';
          } else if (result.message.includes('Invalid login')) {
            errorMessage = 'Invalid username or password. If using Gmail, make sure you\'ve enabled "Less secure app access" or are using an App Password.';
          }

          // Show error modal
          showModal(
            'SMTP Test Failed',
            errorMessage,
            'error'
          );
        }
      }
    } catch (err) {
      // Format error message based on common issues
      let errorMessage = err.message || 'Unknown error';

      if (err.message && err.message.includes('WRONG_VERSION_NUMBER')) {
        errorMessage = 'SSL/TLS configuration error. If using port 587, try setting "secure" to false. If using port 465, set "secure" to true.';
      } else if (err.message && err.message.includes('Invalid login')) {
        errorMessage = 'Invalid username or password. If using Gmail, make sure you\'ve enabled "Less secure app access" or are using an App Password.';
      }

      // Show error modal
      showModal(
        'SMTP Test Failed',
        errorMessage,
        'error'
      );
    } finally {
      setIsLoading(false);
    }
  };

  // Function to toggle the form visibility
  const toggleForm = () => {
    if (showForm) {
      // If we're hiding the form, reset it
      setNewConfig({
        name: '',
        host: '',
        port: '',
        username: '',
        password: '',
        secure: false,
        status: 'Not Tested'
      });
      setEditMode(false);
      setEditingConfigName(null);
    }
    setShowForm(!showForm);
  };

  // Function to toggle advanced settings visibility
  const toggleAdvancedSettings = () => {
    setShowAdvancedSettings(!showAdvancedSettings);
  };

  // Function to toggle config expansion
  const toggleConfigExpansion = (configName) => {
    setExpandedConfigs(prev => ({
      ...prev,
      [configName]: !prev[configName]
    }));
  };

  // Function to show modal
  const showModal = (title, message, type = 'info') => {
    setModalState({
      isOpen: true,
      title,
      message,
      type
    });
  };

  // Function to close modal
  const closeModal = () => {
    setModalState(prev => ({
      ...prev,
      isOpen: false
    }));
  };

  useEffect(() => {
    loadConfigs();
  }, []);

  // Notify parent component when rotation options change
  useEffect(() => {
    if (onRotationOptionsChange && typeof onRotationOptionsChange === 'function') {
      onRotationOptionsChange(rotationOptions);
    }
  }, [rotationOptions, onRotationOptionsChange]);

  return (
    <div className="config-container">
      {/* Modal for SMTP test feedback */}
      <Modal
        isOpen={modalState.isOpen}
        onClose={closeModal}
        title={modalState.title}
        message={modalState.message}
        type={modalState.type}
      />

      {error && (
        <div className="error-message">
          {error}
          <button onClick={() => setError(null)} className="close-btn">✕</button>
        </div>
      )}

      <div className="saved-configs-header">
        <h4>SMTP SETTINGS</h4>
        <button
          onClick={toggleForm}
          className={`add-smtp-button ${showForm ? 'active' : ''}`}
          title={showForm ? 'Cancel' : 'Add New SMTP Configuration'}
        >
          {showForm ? '✕ Cancel' : <><FaPlus /> Add SMTP</>}
        </button>
      </div>

      {/* SMTP Rotation Options - With Clear Advanced Options Label */}
      <div className="smtp-rotation-options">
        <div className="rotation-header" onClick={toggleAdvancedSettings}>
          <h4>
            <FaExchangeAlt className="rotation-icon" />
            SMTP Rotation
            <span className="tooltip-icon">
              <FaInfoCircle title="Configure how SMTPs are rotated during email sending" />
            </span>
          </h4>
          <button className="toggle-advanced-button">
            {showAdvancedSettings ? (
              <>
                <FaCog className="settings-icon" />
                <span className="advanced-label">Hide Advanced Options</span>
                <FaChevronUp />
              </>
            ) : (
              <>
                <FaCog className="settings-icon" />
                <span className="advanced-label">Show Advanced Options</span>
                <FaChevronDown />
              </>
            )}
          </button>
        </div>

        <div className="rotation-options-container">
          {/* Always visible main toggle */}
          <div className="rotation-mode">
            <label className="toggle-switch">
              <input
                type="checkbox"
                checked={rotationOptions.disableRotation}
                onChange={(e) => setRotationOptions({
                  ...rotationOptions,
                  disableRotation: e.target.checked
                })}
              />
              <span className="toggle-slider"></span>
            </label>
            <span className="toggle-label">
              {rotationOptions.disableRotation ?
                <><FaLock /> Use Fixed SMTP</> :
                <><FaExchangeAlt /> Rotate SMTPs</>}
            </span>
          </div>

          {/* Advanced settings (collapsible) */}
          {showAdvancedSettings && (
            <div className="advanced-settings">
              <div className="setting-description">
                {rotationOptions.disableRotation ?
                  "Uses only the first SMTP. Fails over to next SMTP after 2 consecutive failures." :
                  "Rotates through all SMTPs based on batch size."}
              </div>

              <div className="batch-size-selector">
                <label>
                  Batch Size:
                  <span className="tooltip-icon">
                    <FaInfoCircle title="Number of emails to send before rotating to the next SMTP" />
                  </span>
                </label>
                <select
                  value={rotationOptions.batchSize}
                  onChange={(e) => setRotationOptions({
                    ...rotationOptions,
                    batchSize: parseInt(e.target.value, 10)
                  })}
                  disabled={rotationOptions.disableRotation}
                >
                  <option value={50}>50 emails</option>
                  <option value={100}>100 emails</option>
                  <option value={200}>200 emails</option>
                  <option value={400}>400 emails</option>
                  <option value={800}>800 emails</option>
                </select>
                <div className="batch-description">
                  In both modes, if an SMTP fails twice consecutively, it will be skipped until the campaign is restarted.
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* SMTP Configuration Form */}
      {showForm && (
        <div className="config-form-container">
          <form onSubmit={handleSaveConfig} className="config-form">
            <div className="form-group">
              <label htmlFor="name">Configuration Name</label>
              <input
                type="text"
                id="name"
                name="name"
                value={newConfig.name}
                onChange={handleInputChange}
                placeholder="My SMTP Config"
                required
                readOnly={editMode} // Make name field read-only in edit mode
              />
            </div>

            <div className="form-group">
              <label htmlFor="host">SMTP Host</label>
              <input
                type="text"
                id="host"
                name="host"
                value={newConfig.host}
                onChange={handleInputChange}
                placeholder="smtp.example.com"
                required
              />
            </div>

            <div className="form-group">
              <label htmlFor="port">Port</label>
              <input
                type="number"
                id="port"
                name="port"
                value={newConfig.port}
                onChange={handleInputChange}
                placeholder="587"
                required
              />
            </div>

            <div className="form-group">
              <label htmlFor="username">Username</label>
              <input
                type="text"
                id="username"
                name="username"
                value={newConfig.username}
                onChange={handleInputChange}
                placeholder="user@example.com"
                required
              />
            </div>

            <div className="form-group">
              <label htmlFor="password">Password</label>
              <input
                type="password"
                id="password"
                name="password"
                value={newConfig.password}
                onChange={handleInputChange}
                placeholder={editMode ? "Enter new password" : "••••••••"}
                required
              />
            </div>

            <div className="form-group checkbox">
              <input
                type="checkbox"
                id="secure"
                name="secure"
                checked={newConfig.secure}
                onChange={handleInputChange}
              />
              <label htmlFor="secure">Use Secure Connection (SSL/TLS)</label>
            </div>

            <div className="form-actions">
              <button type="submit" className="save-button" disabled={isLoading}>
                {isLoading ? 'SAVING...' : (editMode ? 'UPDATE CONFIGURATION' : 'SAVE CONFIGURATION')}
              </button>
              <button type="button" className="cancel-button" onClick={toggleForm}>
                CANCEL
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Saved SMTP Configurations - Streamlined */}
      <div className="saved-configs">
        <h4>
          <FaServer /> Saved SMTP Servers
          {configs.length > 0 && <span className="config-count">({configs.length})</span>}
        </h4>

        {configs.length === 0 ? (
          <div className="no-configs">No SMTP configurations saved yet</div>
        ) : (
          <div className="configs-list">
            {configs.map((config) => (
              <div key={config.name} className="config-item">
                {/* Compact View (Always Visible) */}
                <div className="config-summary" onClick={() => toggleConfigExpansion(config.name)}>
                  <div className="config-status">
                    {config.status === 'Verified' ? (
                      <span className="status verified" title="Verified"><FaCheck /></span>
                    ) : (
                      <span className="status not-tested" title="Not Tested"><FaQuestion /></span>
                    )}
                  </div>
                  <div className="config-name-container">
                    <span className="config-name">{config.name}</span>
                  </div>
                  <div className="config-actions">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleTestConfig(config);
                      }}
                      disabled={isLoading}
                      className="test-button"
                      title="Test Connection"
                    >
                      Test
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleEditConfig(config);
                      }}
                      disabled={isLoading}
                      className="icon-button"
                      title="Edit Configuration"
                    >
                      <FaEdit />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteConfig(config.name);
                      }}
                      disabled={isLoading}
                      className="icon-button delete"
                      title="Delete Configuration"
                    >
                      <FaTrash />
                    </button>
                    <button
                      className="expand-button"
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleConfigExpansion(config.name);
                      }}
                    >
                      {expandedConfigs[config.name] ? <FaChevronUp /> : <FaChevronDown />}
                    </button>
                  </div>
                </div>

                {/* Expanded Details (Collapsible) */}
                {expandedConfigs[config.name] && (
                  <div className="config-details-expanded">
                    <div className="detail-row">
                      <span className="detail-label">Host:</span>
                      <span className="detail-value">{config.host}</span>
                    </div>
                    <div className="detail-row">
                      <span className="detail-label">Port:</span>
                      <span className="detail-value">{config.port}</span>
                    </div>
                    <div className="detail-row">
                      <span className="detail-label">Username:</span>
                      <span className="detail-value">{config.username}</span>
                    </div>
                    <div className="detail-row">
                      <span className="detail-label">Secure:</span>
                      <span className="detail-value">{config.secure ? 'Yes' : 'No'}</span>
                    </div>
                    <div className="detail-row">
                      <span className="detail-label">Status:</span>
                      <span className={`detail-value status-${config.status === 'Verified' ? 'verified' : 'not-tested'}`}>
                        {config.status}
                      </span>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default SMTPConfig;