import React, { useState, useRef } from 'react';
import { FaImage, FaLink, FaTimes, FaCheck } from 'react-icons/fa';
import Modal from './Modal';
import '../styles/ImageUploader.css';

const ImageUploader = ({ onImageInsert }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [imagePreview, setImagePreview] = useState(null);
  const [imageData, setImageData] = useState(null);
  const [imageUrl, setImageUrl] = useState('');
  const [encodedUrl, setEncodedUrl] = useState('');
  const [isUrlEncoded, setIsUrlEncoded] = useState(false);
  const [error, setError] = useState(null);
  const fileInputRef = useRef(null);

  // Function to handle file selection
  const handleFileSelect = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    // Check file type
    const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
    if (!validTypes.includes(file.type)) {
      setError('Please select a valid image file (JPG, JPEG, PNG, GIF)');
      return;
    }

    // Check file size (max 2MB)
    if (file.size > 2 * 1024 * 1024) {
      setError('Image size should be less than 2MB');
      return;
    }

    setError(null);
    
    // Create preview
    const reader = new FileReader();
    reader.onload = (event) => {
      setImagePreview(event.target.result);
      setImageData(event.target.result);
    };
    reader.readAsDataURL(file);
  };

  // Function to detect if a URL is encoded
  const isEncodedUrl = (url) => {
    // Check if the URL contains HTML entities (&#)
    return /&#\d+;/.test(url);
  };

  // Function to handle URL input
  const handleUrlChange = (e) => {
    const url = e.target.value;
    setImageUrl(url);
    
    // Auto-detect if the URL is encoded
    if (isEncodedUrl(url)) {
      setIsUrlEncoded(true);
      setEncodedUrl(url);
    } else {
      setIsUrlEncoded(false);
      setEncodedUrl('');
    }
  };

  // Function to encode URL to HTML entities
  const encodeUrl = async () => {
    if (!imageUrl) return;
    
    try {
      // If already encoded, don't re-encode
      if (isUrlEncoded) return;
      
      // Convert each character to its HTML entity representation
      const encoded = Array.from(imageUrl)
        .map(char => `&#${char.charCodeAt(0)};`)
        .join('');
      
      setEncodedUrl(encoded);
      setIsUrlEncoded(true);
    } catch (error) {
      setError('Failed to encode URL: ' + error.message);
    }
  };

  // Function to insert the image into the template
  const insertImage = () => {
    if (!imageData) {
      setError('Please select an image first');
      return;
    }

    let imgHtml = `<img src="${imageData}" alt="Inline Image" style="max-width: 100%; height: auto;" />`;
    
    // If URL is provided, wrap the image in an anchor tag
    if (imageUrl) {
      const finalUrl = isUrlEncoded ? encodedUrl : imageUrl;
      imgHtml = `<a href="${finalUrl}" target="_blank">${imgHtml}</a>`;
    }
    
    onImageInsert(imgHtml);
    resetAndClose();
  };

  // Reset state and close modal
  const resetAndClose = () => {
    setImagePreview(null);
    setImageData(null);
    setImageUrl('');
    setEncodedUrl('');
    setIsUrlEncoded(false);
    setError(null);
    setIsModalOpen(false);
    
    // Reset file input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <>
      <button 
        className="image-upload-button" 
        onClick={() => setIsModalOpen(true)}
        title="Insert Inline Image"
      >
        <FaImage /> Insert Image
      </button>
      
      <Modal
        isOpen={isModalOpen}
        onClose={resetAndClose}
        title="Insert Inline Image"
        type="info"
        message={
          <div className="image-uploader-content">
            {error && <div className="image-upload-error">{error}</div>}
            
            <div className="image-upload-section">
              <label className="image-upload-label">Select Image:</label>
              <input
                type="file"
                accept=".jpg,.jpeg,.png,.gif"
                onChange={handleFileSelect}
                className="image-file-input"
                ref={fileInputRef}
              />
              <div className="image-format-info">
                Supported formats: JPG, JPEG, PNG, GIF (max 2MB)
              </div>
            </div>
            
            {imagePreview && (
              <div className="image-preview-container">
                <div className="image-preview-header">Image Preview:</div>
                <img 
                  src={imagePreview} 
                  alt="Preview" 
                  className="image-preview" 
                />
              </div>
            )}
            
            <div className="image-url-section">
              <label className="image-url-label">
                Make Image Clickable (Optional):
              </label>
              <div className="image-url-input-container">
                <input
                  type="text"
                  value={imageUrl}
                  onChange={handleUrlChange}
                  placeholder="Enter URL for the image to link to"
                  className="image-url-input"
                />
                <button 
                  className={`encode-url-button ${isUrlEncoded ? 'encoded' : ''}`}
                  onClick={encodeUrl}
                  disabled={!imageUrl || isUrlEncoded}
                  title="Encode URL with HTML entities"
                >
                  {isUrlEncoded ? <FaCheck /> : <FaLink />}
                </button>
              </div>
              
              {isUrlEncoded && encodedUrl && (
                <div className="encoded-url-preview">
                  <div className="encoded-url-header">Encoded URL (HTML Entities):</div>
                  <div className="encoded-url-content">
                    {encodedUrl.length > 50 
                      ? encodedUrl.substring(0, 50) + '...' 
                      : encodedUrl
                    }
                  </div>
                </div>
              )}
            </div>
            
            <div className="image-upload-actions">
              <button 
                className="insert-image-button"
                onClick={insertImage}
                disabled={!imageData}
              >
                Insert Image
              </button>
              <button 
                className="cancel-upload-button"
                onClick={resetAndClose}
              >
                Cancel
              </button>
            </div>
          </div>
        }
      />
    </>
  );
};

export default ImageUploader;
