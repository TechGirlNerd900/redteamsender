import React, { useState } from 'react';
import { FaLink, FaCheck, FaCopy } from 'react-icons/fa';
import '../styles/UrlEncoderTool.css';

const UrlEncoderTool = ({ onEncodedUrlInsert }) => {
  const [url, setUrl] = useState('');
  const [encodedUrl, setEncodedUrl] = useState('');
  const [isEncoding, setIsEncoding] = useState(false);
  const [isCopied, setIsCopied] = useState(false);
  const [error, setError] = useState(null);

  // Function to encode URL to HTML entities
  const encodeUrl = () => {
    if (!url.trim()) {
      setError('Please enter a URL to encode');
      return;
    }

    setIsEncoding(true);
    setError(null);

    try {
      // Convert each character to its HTML entity representation
      const encoded = Array.from(url)
        .map(char => `&#${char.charCodeAt(0)};`)
        .join('');
      
      setEncodedUrl(encoded);
      setIsEncoding(false);
    } catch (err) {
      setError('Failed to encode URL: ' + err.message);
      setIsEncoding(false);
    }
  };

  // Function to copy encoded URL to clipboard
  const copyToClipboard = () => {
    if (!encodedUrl) return;
    
    navigator.clipboard.writeText(encodedUrl)
      .then(() => {
        setIsCopied(true);
        setTimeout(() => setIsCopied(false), 2000);
      })
      .catch(() => {
        setError('Failed to copy to clipboard');
      });
  };

  // Function to insert encoded URL into template
  const insertEncodedUrl = () => {
    if (!encodedUrl) return;
    onEncodedUrlInsert(encodedUrl);
    
    // Reset the form
    setUrl('');
    setEncodedUrl('');
  };

  return (
    <div className="url-encoder-tool">
      <div className="url-encoder-header">
        <FaLink className="url-icon" />
        <span>Encode URL for Template</span>
      </div>
      
      {error && <div className="url-encoder-error">{error}</div>}
      
      <div className="url-input-container">
        <input
          type="text"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder="Enter URL to encode"
          className="url-input"
        />
        <button
          className="encode-button"
          onClick={encodeUrl}
          disabled={isEncoding || !url.trim()}
        >
          {isEncoding ? 'Encoding...' : 'Encode'}
        </button>
      </div>
      
      {encodedUrl && (
        <div className="encoded-result">
          <div className="encoded-result-header">Encoded URL:</div>
          <div className="encoded-result-content">
            {encodedUrl.length > 40 
              ? encodedUrl.substring(0, 40) + '...' 
              : encodedUrl
            }
          </div>
          <div className="encoded-result-actions">
            <button
              className="copy-button"
              onClick={copyToClipboard}
              title="Copy to clipboard"
            >
              {isCopied ? <><FaCheck /> Copied!</> : <><FaCopy /> Copy</>}
            </button>
            <button
              className="insert-button"
              onClick={insertEncodedUrl}
              title="Insert into template"
            >
              Insert
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default UrlEncoderTool;
