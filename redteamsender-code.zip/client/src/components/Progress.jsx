import React, { useState, useEffect, useRef } from 'react';
import '../styles/Progress.css';

const Progress = ({ status, message, current, total, percentage }) => {
    const [showMilestoneEffect, setShowMilestoneEffect] = useState(false);
    const [lastMilestone, setLastMilestone] = useState(0);
    const progressBarRef = useRef(null);

    // Calculate percentage if not provided
    const calculatedPercentage = percentage || (total > 0 ? Math.round((current / total) * 100) : 0);

    // Check for milestone (every 100 emails or 25% progress)
    useEffect(() => {
        if (status === 'sending' && total > 0) {
            // Check for milestone based on count (every 100 emails)
            if (current > 0 && current % 100 === 0 && current !== lastMilestone) {
                setShowMilestoneEffect(true);
                setLastMilestone(current);

                // Hide the effect after animation completes
                setTimeout(() => {
                    setShowMilestoneEffect(false);
                }, 1500);
            }
        }
    }, [current, total, status, lastMilestone]);

    const getStatusClass = () => {
        switch (status) {
            case 'sending':
                return 'progress-sending';
            case 'complete':
                return 'progress-complete';
            case 'error':
                return 'progress-error';
            case 'cancelled':
                return 'progress-cancelled';
            default:
                return 'progress-idle';
        }
    };

    return (
        <div className={`progress-container ${getStatusClass()}`}>
            <div className="progress-status">
                {status === 'sending' && (
                    <div className="progress-spinner">
                        <div className="spinner"></div>
                    </div>
                )}
                <span className="status-text">{message || 'Ready to send'}</span>
            </div>

            <div className="progress-details">
                {status === 'sending' && total > 0 && (
                    <div className="progress-count">
                        <span className="current-count">{current}</span>
                        <span className="count-separator"> / </span>
                        <span className="total-count">{total}</span>
                        <span className="emails-text"> emails sent</span>
                    </div>
                )}
            </div>

            <div className="progress-bar-container">
                <div
                    ref={progressBarRef}
                    className={`progress-bar ${showMilestoneEffect ? 'milestone-reached' : ''}`}
                >
                    <div
                        className="progress-fill"
                        style={{
                            width: status === 'sending' && total > 0 ? `${Math.min(100, calculatedPercentage)}%` :
                                status === 'complete' ? '100%' :
                                status === 'cancelled' ? `${Math.min(100, calculatedPercentage)}%` : '0%'
                        }}
                    >
                        {showMilestoneEffect && (
                            <div className="milestone-ripple"></div>
                        )}
                    </div>
                </div>

                {status === 'sending' && total > 0 && (
                    <div className="progress-percentage">
                        {calculatedPercentage}%
                    </div>
                )}
            </div>
        </div>
    );
};

export default Progress;