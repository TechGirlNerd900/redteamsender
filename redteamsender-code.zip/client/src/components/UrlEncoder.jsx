import React, { useState, useEffect } from 'react';
import { isElectron, callElectronAPI } from '../utils/electronUtils';
import { FaTimes, FaCheck, FaCopy } from 'react-icons/fa';
import '../styles/UrlEncoder.css';

const UrlEncoder = () => {
    const [url, setUrl] = useState('');
    const [encodedUrl, setEncodedUrl] = useState('');
    const [isEncoding, setIsEncoding] = useState(false);
    const [error, setError] = useState(null);
    const [copyStatus, setCopyStatus] = useState('');
    const [autoResetTimer, setAutoResetTimer] = useState(null);

    // Clear the auto-reset timer when component unmounts
    useEffect(() => {
        return () => {
            if (autoResetTimer) {
                clearTimeout(autoResetTimer);
            }
        };
    }, [autoResetTimer]);

    // Function to reset the encoder state
    const resetEncoder = () => {
        setEncodedUrl('');
        setCopyStatus('');
        if (autoResetTimer) {
            clearTimeout(autoResetTimer);
            setAutoResetTimer(null);
        }
    };

    const handleUrlChange = (e) => {
        setUrl(e.target.value);
        setError(null);
    };

    const handleEncode = async () => {
        if (!url.trim()) {
            setError('Please enter a URL to encode');
            return;
        }

        setIsEncoding(true);
        setError(null);

        try {
            let result;

            if (isElectron()) {
                // Call the Electron API if running in Electron
                result = await callElectronAPI('encodeUrl', url);
            } else {
                // Otherwise, call the server API directly
                const response = await fetch('/api/url-encoder/encode', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ url }),
                });

                result = await response.json();
            }

            if (result.success) {
                setEncodedUrl(result.encodedUrl);
            } else {
                setError(result.message || 'Failed to encode URL');
            }
        } catch (err) {
            setError(err.message || 'An error occurred while encoding the URL');
        } finally {
            setIsEncoding(false);
        }
    };

    const handleCopy = () => {
        if (encodedUrl) {
            navigator.clipboard.writeText(encodedUrl)
                .then(() => {
                    // Show success status
                    setCopyStatus('copied');

                    // Clear any existing timer
                    if (autoResetTimer) {
                        clearTimeout(autoResetTimer);
                    }

                    // Set a new timer to auto-reset after 5 seconds
                    const timer = setTimeout(() => {
                        resetEncoder();
                    }, 5000);

                    setAutoResetTimer(timer);
                })
                .catch(err => {
                    setError('Failed to copy to clipboard');
                });
        }
    };

    return (
        <div className="url-encoder">
            <h3>URL Encoder (HTML Entities)</h3>

            <div className="encoder-form">
                <div className="form-group">
                    <label htmlFor="url-input">URL to Encode:</label>
                    <input
                        id="url-input"
                        type="text"
                        value={url}
                        onChange={handleUrlChange}
                        placeholder="Enter URL to encode"
                        disabled={isEncoding}
                    />
                </div>

                <button
                    className="encode-button"
                    onClick={handleEncode}
                    disabled={isEncoding || !url.trim()}
                >
                    {isEncoding ? 'Encoding...' : 'Encode URL'}
                </button>

                {error && <div className="error-message">{error}</div>}

                {encodedUrl && (
                    <div className="result-container">
                        <div className="result-header">
                            <label htmlFor="encoded-url">Encoded URL:</label>
                            <button
                                className="reset-button"
                                onClick={resetEncoder}
                                title="Reset encoder"
                            >
                                <FaTimes />
                            </button>
                        </div>
                        <textarea
                            id="encoded-url"
                            value={encodedUrl}
                            readOnly
                            rows={4}
                        />
                        <div className="result-actions">
                            <button
                                id="copy-button"
                                className={`copy-button ${copyStatus === 'copied' ? 'copied' : ''}`}
                                onClick={handleCopy}
                            >
                                {copyStatus === 'copied' ? (
                                    <>
                                        <FaCheck /> Copied to Clipboard!
                                    </>
                                ) : (
                                    <>
                                        <FaCopy /> Copy to Clipboard
                                    </>
                                )}
                            </button>
                            <div className="auto-reset-notice">
                                {copyStatus === 'copied' && (
                                    <span>Will reset in 5 seconds...</span>
                                )}
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default UrlEncoder;
