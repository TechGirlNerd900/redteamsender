/**
 * URL Encoder - HTML Entity Encoding
 * 
 * This script encodes URLs by converting each character to its HTML entity representation.
 * JavaScript replacement for the Python url_encoder.py script.
 */

/**
 * Encode a URL by converting each character to its HTML entity representation.
 * 
 * @param {string} url - The URL to encode
 * @returns {string} The encoded URL with HTML entities
 */
function encodeHtmlEntities(url) {
  if (!url) return '';
  
  return Array.from(url)
    .map(char => `&#${char.charCodeAt(0)};`)
    .join('');
}

// Make the function available for different environments

// For CommonJS (Node.js)
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { encodeHtmlEntities };
  
  // If this script is run directly (not imported)
  if (require.main === module) {
    const readline = require('readline');
    const rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout
    });
    
    rl.question('Enter URL to encode: ', (url) => {
      console.log(encodeHtmlEntities(url));
      rl.close();
    });
  }
}

// For AMD (RequireJS)
if (typeof define === 'function' && define.amd) {
  define([], function() {
    return { encodeHtmlEntities };
  });
}

// For browser environment
if (typeof window !== 'undefined') {
  window.encodeHtmlEntities = encodeHtmlEntities;
}

// For ES modules
if (typeof exports !== 'undefined') {
  exports.encodeHtmlEntities = encodeHtmlEntities;
}
